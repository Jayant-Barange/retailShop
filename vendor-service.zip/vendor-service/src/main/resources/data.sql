insert into vendor (vendor_id,delivery_charge,rating,vendor_name) values(1,40,5,'Sharma Vendors');
insert into vendor (vendor_id,delivery_charge,rating,vendor_name)  values(2,50,4,'Sagar Vendors');


insert into vendor_stock values(1,'2020-12-12',1,50,1);
insert into vendor_stock values(2,'2021-2-1',1,100,2);
insert into vendor_stock values(3,'2021-1-1',2,50,1);
insert into vendor_stock values(4,'2021-2-2',2,100,2);