package com.cts.ProceedToBuy.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cts.ProceedToBuy.model.CustomErrorResponse;



@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(VendorNotFoundException.class)
	public ResponseEntity<CustomErrorResponse> handleVendorNotFoundException(VendorNotFoundException ex){
		CustomErrorResponse response = new CustomErrorResponse();
		response.setTimestamp(LocalDateTime.now());
		response.setMessage(ex.getMessage());
		response.setStatus(HttpStatus.NOT_FOUND);
		response.setReason("Invalid User Id Provided");
		return new ResponseEntity<CustomErrorResponse>(response, HttpStatus.NOT_FOUND);
	}
	
}
