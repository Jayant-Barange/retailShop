package com.cts.ProceedToBuy.feignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import feign.Headers;

@FeignClient(name="Product",url="http://localhost:8081")
@Headers("Content-Type: application/json")
public interface ProductClient {

	@GetMapping("/vendorService/getVendorDetails/{productId}")
	Double getProductPrice(@RequestHeader(name = "Authorization") String token,
			@PathVariable("productId") int productId);
}
