package com.cts.ProceedToBuy.controller;


import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ProceedToBuy.feignClient.AuthClient;
import com.cts.ProceedToBuy.model.Cart;
import com.cts.ProceedToBuy.model.CartData;
import com.cts.ProceedToBuy.model.Info;
import com.cts.ProceedToBuy.model.ProductCart;
import com.cts.ProceedToBuy.model.WishListData;
import com.cts.ProceedToBuy.service.CartService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/proceedToBuy")
public class CartController {
	@Autowired
	AuthClient authClient;
	@Autowired
	CartService cartService;
	
	@PostMapping("/addProductToCart")
	public Cart addToCart(@RequestHeader(name = "Authorization") String token,@RequestBody CartData data) throws ParseException {
			Cart cart = cartService.addToCart(token,data);
		return cart;
	}
	
	
	@PostMapping("/addProductToWishlist")
	public String addProductToWishlist(@RequestHeader(name = "Authorization") String token,@RequestBody WishListData data) {
		//log.info(token+customerId+customerId,productId,quantity);
		return cartService.addToWishList(token,data.getProductId(),data.getCustomerId(),data.getQuantity());
	}
	
	
//	@GetMapping("/viewProductCart")
//	public ProductCart viewProductCart(@RequestHeader(name = "Authorization") String token,@RequestBody Info info) {
//		return cartService.showProductCart(token,info);
//	}

}
