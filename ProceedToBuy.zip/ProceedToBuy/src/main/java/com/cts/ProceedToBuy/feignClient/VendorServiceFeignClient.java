package com.cts.ProceedToBuy.feignClient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.ProceedToBuy.model.Info;
import com.cts.ProceedToBuy.model.Vendor;

import feign.Headers;

@FeignClient(name="vendorService",url="http://localhost:9000")
@Headers("Content-Type: application/json")
public interface VendorServiceFeignClient {

	@GetMapping("/vendorService/getVendorDetails/{productId}")
	List<Vendor> getVendorDetails(@RequestHeader(name = "Authorization") String token,
			@PathVariable("productId") int productId);

	@GetMapping("/vendorService/getVendorOnRating/{productId}")
	int getVendorOnRating(@RequestHeader(name = "Authorization") String token,@PathVariable("productId") int productId);
	
	@GetMapping("/vendorService/getVendorData")
	public ResponseEntity<?> getVendorData(@RequestBody Info info);
}
