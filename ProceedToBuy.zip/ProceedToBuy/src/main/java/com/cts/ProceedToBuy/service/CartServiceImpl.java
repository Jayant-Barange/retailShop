package com.cts.ProceedToBuy.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cts.ProceedToBuy.exception.VendorNotFoundException;
import com.cts.ProceedToBuy.feignClient.ProductClient;
import com.cts.ProceedToBuy.feignClient.VendorServiceFeignClient;
import com.cts.ProceedToBuy.model.Cart;
import com.cts.ProceedToBuy.model.CartData;
import com.cts.ProceedToBuy.model.Info;
import com.cts.ProceedToBuy.model.ProductCart;
import com.cts.ProceedToBuy.model.Vendor;
import com.cts.ProceedToBuy.model.VendorData;
import com.cts.ProceedToBuy.model.VendorWishlist;
import com.cts.ProceedToBuy.repositor.CartRepository;
import com.cts.ProceedToBuy.repositor.WishListRepository;


@Service
public class CartServiceImpl implements CartService {

	
	@Autowired
	CartRepository cartRepo;
	@Autowired
	WishListRepository wishListRepository;
	@Autowired
	VendorServiceFeignClient vendorServiceFeignClient;
	@Autowired
	ProductClient productClient;
	
	@Override
	public Cart addToCart(String token,CartData data) {
		// TODO Auto-generated method stub
		
		System.out.println("printing cartdata "+data.getCustomerId()+data.getExpectedDeleveryDate());
		Cart cart = new Cart();
		java.util.Date date = null;
		try {
			date = new SimpleDateFormat("dd/mm/yyyy").parse(data.getExpectedDeleveryDate());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Date sDate = new java.sql.Date(date.getTime());
		//List<Vendor> vendorList = vendorServiceFeignClient.getVendorDetails(token, data.getProductId());
		System.out.println("running fine"+token+data);
		
		int vendorId;
			cart.setDilevryDate(sDate); 
			cart.setProductId(data.getProductId());
			try {
				vendorId=vendorServiceFeignClient.getVendorOnRating(token,data.getProductId());
			cart.setVendorId(vendorId);
			System.out.println("printing vendorid"+vendorId);
			}catch(Exception e) {
				throw new VendorNotFoundException("Can't find vendor!");
			}
			cart.setZipCode(data.getZipCode());
			cart.setCustomerId(data.getCustomerId());
			System.out.println("trying to print cart before saving"+cart.toString());
			cart = cartRepo.save(cart);
			
			System.out.println(cart.toString());
		return cart;
	
	}

	@Override
	public String addToWishList(String token,Integer productId, Integer customerId, Integer quantity) {
		// TODO Auto-generated method stub
		VendorWishlist vendorWishlist = new VendorWishlist();
		vendorWishlist.setProductId(productId);
		vendorWishlist.setQuantity(quantity);
		try {
		vendorWishlist.setVendorId(vendorServiceFeignClient.getVendorOnRating(token,productId));
		}catch(Exception e) {
			throw new VendorNotFoundException("Can't find vendor!");
		}
		vendorWishlist.setAddedDate(new java.sql.Date(System.currentTimeMillis()));
		//vendorWishlist = null;
		vendorWishlist = wishListRepository.save(vendorWishlist);
		String str = "Sorry some error occured while adding to wishlist";
		if(vendorWishlist!=null)
			str = "Added to wishlist successfully!";

		return str;
	}

//	@Override
//	public ProductCart showProductCart(String token, Info info) {
//		ProductCart productCart =new ProductCart();
//		ResponseEntity<VendorData> vData = (ResponseEntity<VendorData>) vendorServiceFeignClient.getVendorData(info);
//		double price = productClient.getProductPrice(token, info.getProductId());
//		productCart.setDate(vData.getBody().getDate());
//		productCart.setDeliveryCharge(vData.getBody().getDeliveryCharge());
//		productCart.setPrice(price);
//		productCart.setVendorId(vData.getBody().getVendorId());
//		productCart.setVendorName(vData.getBody().getVendorName());
//		return productCart;
//	}
	
	

}
