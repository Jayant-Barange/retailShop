package com.cts.ProceedToBuy.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CartData {

	@Id
	private int customerId;
	private int productId;
	private int zipCode;
	private String expectedDeleveryDate;
	
	
	
	
}
