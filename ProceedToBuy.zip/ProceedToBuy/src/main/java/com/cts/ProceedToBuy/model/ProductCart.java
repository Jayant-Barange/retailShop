package com.cts.ProceedToBuy.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductCart {

	@Id
	private int vendorId;
	
	private String vendorName;
	
	private float deliveryCharge;
	
	private Date date;
	
	private double price;
}
