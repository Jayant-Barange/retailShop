package com.cts.ProceedToBuy.exception;

public class VendorNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	public VendorNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public VendorNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
