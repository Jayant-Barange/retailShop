package com.cts.ProceedToBuy.service;

import com.cts.ProceedToBuy.model.Cart;
import com.cts.ProceedToBuy.model.CartData;
import com.cts.ProceedToBuy.model.Info;
import com.cts.ProceedToBuy.model.ProductCart;

public interface CartService {

	Cart addToCart(String token, CartData data);

	String addToWishList(String token,Integer vendorId, Integer productId, Integer quantity);

	//ProductCart showProductCart(String token, Info info);

}
