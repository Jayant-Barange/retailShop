insert into Product(id,price,name,description,image_name,rating,count) values (1,45,'Maggie','Taste good','Maggie Image',4,1);
insert into Product(id,price,name,description,image_name,rating,count) values (2,40,'Pasta','Taste good','Pasta Image',5,1);
insert into Product(id,price,name,description,image_name,rating,count) values (3,20,'Biscuit','Taste good','Biscuit Image',4,1);
