package com.cts.product.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.product.exception.IdNotFoundException;
import com.cts.product.exception.NameNotFoundException;
import com.cts.product.exception.RatingNotAddedException;
import com.cts.product.model.Product;
import com.cts.product.repository.ProductRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	
	//Method for finding Product By Id
	
	@Override
	public Optional<Product> viewProductById(long id) {
		log.info("Start of service");
		log.info("In viewProductById() Method");
		Optional<Product> optional= productRepository.findById(id);    /*.orElseThrow(()->new IdNotFoundException("Product id "+id+" does not exist"));*/
		
		if(!optional.isPresent())
		{
			throw new IdNotFoundException("Product Id "+id+" is inactive or out of stock");
		}
		
		log.info("Product Id : {}",new Long(id).toString());
		log.info("End ofservice");
		return optional;
	}

	
	//Method for finding Product By Name
	
	@Override
	public Optional<Product> viewProductByName(String name) {
		log.info("Start");
		log.info("In viewProductByName() Method");
		Optional<Product> optional= productRepository.findByName(name);
		
		if(!optional.isPresent())
		{
			throw new NameNotFoundException("Product Name "+name+" is inactive or out of stock");
		}
		
		log.info("Product Name : {}",name);
		log.info("End");
		return optional;	
	}


	@Override
	public void save(Product pro) {
		log.info("Start");
		productRepository.save(pro);
		log.info("End");
	}


	@Override
	public void setdata(Optional<Product> optional, Product product) {
		log.info("Start");
		try{
			Product pro=optional.get();
		double rating=pro.getRating();
		double currentRating=product.getRating();
		int count= pro.getCount();
			
		
		rating=((rating*count)+currentRating)/(++count);
				
		pro.setRating(rating);
		
		pro.setCount(count);
		save(pro);
		}
		catch(Exception ex){
			throw new RatingNotAddedException("Product Name "+product.getRating()+" does not exist");
		}
		log.info("End");
	}


	


	

}
