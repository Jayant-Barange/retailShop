package com.cts.product.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.product.feign.AuthClient;
import com.cts.product.model.AuthResponse;
import com.cts.product.model.Product;
import com.cts.product.service.ProductService;


import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/product")
public class ProductController  {

	@Autowired(required=true)
	private ProductService service;
	@Autowired(required=true)
	AuthClient authClient;
	@GetMapping("/")
	@ApiOperation(value="Home Page", notes="welcome Home page")
	 public ResponseEntity<?> getHome(@RequestHeader(name = "Authorization") String token) {
		log.info("Start");
		log.info("In getHome() Method");
		AuthResponse response = authClient.verifyToken(token);
		if (response.isValid()) {
			log.info("End Successful");
			return new ResponseEntity<>("Welcome Piyush", HttpStatus.OK);
		} else {
			log.info("End Unsuccessful");
			return new ResponseEntity<>("Please provide correct credentials", HttpStatus.FORBIDDEN);

		}
		 
	 }	
	
	@GetMapping("/id/{id}")
	@ApiOperation(value="Find Products By Id", notes="Provide an Id to look up specific Product")
	public ResponseEntity<?>  searchProductId(@RequestHeader(name = "Authorization") String token,@PathVariable ("id")long id)
	{
		log.info("Start" +token);
		log.info("In getProductId() Method"+id);
		
		AuthResponse response = authClient.verifyToken(token);
		log.info("after auth verify");
		if (response.isValid()) {
			log.info("End Successful");
			Optional<Product> optional=service.viewProductById(id);
			return new ResponseEntity<>(optional.get(), HttpStatus.OK);
		} else {
			log.info("End Unsuccessful");
			return new ResponseEntity<>("Please provide correct credentials", HttpStatus.FORBIDDEN);

		}
		
	
	}
	
	@GetMapping("/name/{name}")
	@ApiOperation(value="Find Products By Name", notes="Provide an Name to look up specific Product")
	public ResponseEntity<?> searchProductName(@RequestHeader(name = "Authorization") String token,@PathVariable("name") String name)
	{
		log.info("Start");
		log.info("In getProductName() Method");
		AuthResponse response = authClient.verifyToken(token);
		
		if (response.isValid()) {
			log.info("End Successful");
			Optional<Product> optional=service.viewProductByName(name);
			return new ResponseEntity<>(optional.get(), HttpStatus.OK);
		} else {
			log.info("End Unsuccessful");
			return new ResponseEntity<>("Please provide correct credentials", HttpStatus.FORBIDDEN);

		}
	
	}
	
	@PostMapping("/rating/{id}")
	@ApiOperation(value="Add Products Rating", notes="Provide rating by adding an Id")
	public ResponseEntity<?>  addProductRating(@RequestHeader(name = "Authorization") String token,@PathVariable("id") long id,@RequestBody Product product )
	{
		log.info("Start");
		log.info("In addProductRating() Method");
AuthResponse response = authClient.verifyToken(token);
		
		if (response.isValid()) {
			log.info("End Successful");
			Optional<Product> optional=service.viewProductById(id);
			log.info("Return to addProductRating method");
			service.setdata(optional,product);
			return new ResponseEntity<>("Rating Recorded Successfully", HttpStatus.OK);
		} else {
			log.info("End Unsuccessful");
			return new ResponseEntity<>("Please provide correct credentials", HttpStatus.FORBIDDEN);

		}
		
	}
	
	
//	@GetMapping("/price")
//	public  Product getProductPrice(@RequestBody long id){
//		
//		Optional<Product> optional=service.viewProductById(id);
//		
//		return optional.get();
//		
//	}
	@GetMapping("/checkout/{id}")
	public Product getProductPrice(@PathVariable long id) {

		Optional<Product> optional = service.viewProductById(id);

		return optional.get();

	}
	
}
