package com.cts.product.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cts.product.model.Product;


public interface ProductService {

	Optional<Product> viewProductById(long id);

	Optional<Product> viewProductByName(String name);

	void save(Product pro);

	void setdata(Optional<Product> optional, Product product);

	

	

}
