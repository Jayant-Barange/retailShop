package com.cts.product.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cts.product.model.CustomErrorResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class GlobalErrorHandler {

	//Exception handled for Id Not found
	
	@ExceptionHandler(IdNotFoundException.class)
	public ResponseEntity<CustomErrorResponse> handleIdNotFoundexception(IdNotFoundException ex)
	{
		log.info("Start");
		log.info("In handleIdNotFoundexception() method");
		CustomErrorResponse response=new CustomErrorResponse();
		response.setTimestamp(LocalDateTime.now());
		response.setMessage(ex.getMessage());
		response.setStatus(HttpStatus.NOT_FOUND);
		response.setReason("Product Id Not Found");
		log.info("End");
		return new ResponseEntity<CustomErrorResponse>(response,HttpStatus.NOT_FOUND);
	}
	
	//Exception handled for Name Not found
	
	
	@ExceptionHandler(NameNotFoundException.class)
	public ResponseEntity<CustomErrorResponse> handleNameNotFoundexception(NameNotFoundException ex)
	{
		log.info("Start");
		log.info("In handleNameNotFoundexception() method");
		CustomErrorResponse response=new CustomErrorResponse();
		response.setTimestamp(LocalDateTime.now());
		response.setMessage(ex.getMessage());
		response.setStatus(HttpStatus.NOT_FOUND);
		response.setReason("Product Name Not Found");
		log.info("End");
		return new ResponseEntity<CustomErrorResponse>(response,HttpStatus.NOT_FOUND);
	}
	
	//Exception handled for Rating Not Added
	
	
		@ExceptionHandler(RatingNotAddedException.class)
		public ResponseEntity<CustomErrorResponse> handleRatingNotAddedexception(RatingNotAddedException ex)
		{
			log.info("Start");
			log.info("In RatingNotAddedException() method");
			CustomErrorResponse response=new CustomErrorResponse();
			response.setTimestamp(LocalDateTime.now());
			response.setMessage(ex.getMessage());
			response.setStatus(HttpStatus.NOT_MODIFIED);
			response.setReason("Product Rating Not Added");
			log.info("End");
			return new ResponseEntity<CustomErrorResponse>(response,HttpStatus.NOT_MODIFIED);
		}
	
	
	//Catch All Exception
	
		@ExceptionHandler(Exception.class)
		public ResponseEntity<CustomErrorResponse> handleAllErrors(Exception ex)
		{
			log.info("Start exception");
			log.info("In handleAllErrors() method");
			CustomErrorResponse response=new CustomErrorResponse();
			response.setTimestamp(LocalDateTime.now());
			response.setMessage(ex.getMessage());
			response.setStatus(HttpStatus.BAD_REQUEST);
			response.setReason("Bad request");
			log.info("End of handleAllErrors");
			return new ResponseEntity<CustomErrorResponse>(response, HttpStatus.NOT_FOUND);
		}
	
}
